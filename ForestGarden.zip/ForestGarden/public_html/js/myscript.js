   
   /*for Registration*/
   
   function checkFirstNameValue(){
                var firstName=$("#fname").val().length;
         if(firstName<7 || firstName > 15)
         {
           $("#firsterror").text("Your First Name must be between 8 to 15 characters");
              $("#firsterror").show();
              return false;
         }
         else
         {
       $("#firsterror").hide();
      
         }
    }
	
	    $("#fname").blur(function(){
    checkFirstNameValue();
    });
    
	
	
	
	
	 function checkLastNameValue(){
              var lastName=$("#lname").val().length;
         if(lastName<7 || lastName > 15)
         {
           $("#lasterror").text("Your last Name must be between 8 to 15 characters");
              $("#lasterror").show();
              return false;
         }
         else
         {
       $("#lasterror").hide();
         }
      }
   
   
   
    $("#lname").blur(function(){
    checkLastNameValue();
    });
    
    
    
    
    
	
	function checkValidEmail() {
                var email=$("#email").val().length;
     if(email==0)
         {
           $("#emailerror").text("email address must not be empty");
           $("#emailerror").show();
           return false;
         }
         else
         {
       $("#emailerror").hide();
         }
    }
    
    
     $("#email").blur(function(){
          checkValidEmail();
    });
    
    
    
    
	
	
   
    function checkPassword(){
             var password=$("#pass1").val().length;
         if(password<7 || password > 15)
         {
           $("#passerror").text("Your password must be between 8 to 15 characters");
              $("#passerror").show();
              return false;
         }
         else
         {
       $("#passerror").hide();
         }
    }
    
    
    
    
        $("#pass1").blur(function(){
          checkPassword();
    });
	
	
	
	
	
	
	function checkMobile(){
          var mobile=$("#phone").val().length;
         if(mobile<11 || mobile >20)
         {
           $("#mobierror").text("Please input Valid Number");
              $("#mobierror").show();
              return false;
         }
         else
         {
       $("#mobierror").hide();
         }
    }
    
    
        $("#phone").blur(function(){
      checkMobile();
    });
    
	
	
	
	
	
	
	$("#myForm").submit(function(){
        var fname=checkFirstNameValue();
        var lname=checkLastNameValue();
        var email=checkValidEmail();
        var pass=checkPassword();
       
        var mobile=checkMobile();
        
        if(fname==false || lname==false || email==false || pass==false || mobile==false)
        {
            return false;
        }
        else
        {
            return true;
        }
        
    });
	
	
	/*endof registration*/
	
	
	/*login*/
	
	
	  function checkUserNameValue(){
                var firstName=$("#uname").val().length;
         if(firstName<7 || firstName > 15)
         {
           $("#userrror").text("Your User Name must be between 8 to 15 characters");
              $("#userrror").show();
              return false;
         }
         else
         {
       $("#userrror").hide();
      
         }
    }
	
	    $("#uname").blur(function(){
    checkUserNameValue();
    });
    
	
	
	
	   function checkMyPassword(){
             var password=$("#pass2").val().length;
         if(password<7 || password > 15)
         {
           $("#mypassrrror").text("Your password must be between 8 to 15 characters");
              $("#mypassrrror").show();
              return false;
         }
         else
         {
       $("#mypassrrror").hide();
         }
    }
    
    
    
    
        $("#pass2").blur(function(){
          checkMyPassword();
    });
	
	
	
	
	
	$("#myLogin").submit(function(){
        var username=checkUserNameValue();
        var mypass=checkMyPassword();
      
       
       
        
        if(username==false ||mypass==false)
        {
            return false;
        }
		
		else 
		{
			alert('Your LoginProcess Success');
            return true;
		}
     
        
    });

	/*endofLogin*/
	
	
	
	/*scrollprocess*/
	
           $(window).scroll(function(){
		      if($(this).scrollTop()>0){
			    $('.scrollup').fadeIn();
			  } 
			  
			  else
			  {
			    $('.scrollup').fadeOut();
			  }
		   });    
		
		
		
	
		
	
		
		
		$(".scrollup").click(function(){
		      $("html, body").animate({
			     scrollTop:0
			  },600);
			  return false;
		   });
		
    /*end of scrollprocess*/
	
	/*newsbox*/
	 $(function () {
        $(".demo1").bootstrapNews({
            newsPerPage: 3,
            autoplay: true,
			pauseOnHover:true,
            direction: 'up',
            newsTickerInterval: 4000,
            onToDo: function () {
                //console.log(this);
            }
        });
		
		$(".demo2").bootstrapNews({
            newsPerPage: 5,
            autoplay: true,
			pauseOnHover: true,
			navigation: false,
            direction: 'down',
            newsTickerInterval: 2500,
            onToDo: function () {
                //console.log(this);
            }
        });

        $("#demo3").bootstrapNews({
            newsPerPage: 3,
            autoplay: false,
            
            onToDo: function () {
                //console.log(this);
            }
        });
    });
	
	
	/*endof newsbox*/